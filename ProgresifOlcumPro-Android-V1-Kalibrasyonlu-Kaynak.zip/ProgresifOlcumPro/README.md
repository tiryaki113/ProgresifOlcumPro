# Progresif Ölçüm Pro — V1.1 (yardımlı işaretleme)

Android uygulaması; arka kamera veya galeriden alınan fotoğrafta klipsli aparat ve göz/cam referans noktalarını optisyen tarafından elle işaretleyerek ön ölçüm değerleri hesaplar.

## Kalibrasyon varsayımları
- Aparatın üst sol ve üst sağ dış referansları arası: 170 mm.
- Üst ve alt referans sıraları arası: 60 mm (sol ve sağ taraftaki mesafelerin ortalaması kullanılır).
- Üst ortadaki yuvarlak işaret: monoküler PD için yatay merkez referansı.
- Fotoğrafta kişinin anatomik sağı görüntünün solunda kabul edilir.

## İşaretleme sırası
1. Üst sol dış referans
2. Üst sağ dış referans
3. Alt sol dış referans
4. Alt sağ dış referans
5. Üst orta yuvarlak merkez işareti
6. Kişinin sağ göz bebeği merkezi (görüntünün solu)
7. Kişinin sol göz bebeği merkezi (görüntünün sağı)
8. Kişinin sağ cam alt kenarı, pupil hizası
9. Kişinin sol cam alt kenarı, pupil hizası

## Hesaplama
Yatay piksel ölçeği üst dış referanslar arasındaki 170 mm mesafeden, dikey piksel ölçeği iki yandaki üst-alt referans uzaklıklarının ortalamasından 60 mm kabul edilerek hesaplanır. Monoküler PD merkez işaretine göre, montaj yüksekliği pupil ile ilgili cam alt kenarı arasındaki dikey uzaklıktan hesaplanır.

## Önemli sınırlamalar
- Bu sürüm otomatik aparat/göz bebeği algılamaz; tüm noktalar kullanıcı tarafından elle işaretlenir.
- Bu sürüm perspektif/homografi düzeltmesi yapmaz. Eğik çekim, aparatın kameraya göre dönük olması, lens düzleminin farklı derinlikte bulunması veya referansların hatalı işaretlenmesi ölçümü bozar.
- Kullanıcının bildirdiği 170 × 60 mm ölçüleri aparat üzerinde fiziksel olarak doğrulanmalıdır. Dört dış noktanın geometrisi dikdörtgen kabul edilir.
- Sonuçlar yalnızca geliştirme ve karşılaştırma amaçlı ön değerlerdir. Gerçek hasta ölçüsü/cam siparişi için kalibre edilmiş optik ölçüm cihazı ve optisyen kontrolü gerekir.
