# Progresif Ölçüm Pro — Android V1 iskeleti

Bu proje, arka kamera ve gözlük çerçevesine takılan klipsli kalibrasyon aparatıyla progresif montaj ölçüm iş akışının ilk Android iskeletidir.

## Bu ilk kaynak pakette bulunanlar
- Türkçe ana ekran taslağı
- Android CameraX arka kamera önizlemesi
- En yüksek kalite modunda fotoğraf çekimi (uygulamanın geçici klasörüne kaydetme)
- Ölçüm matematiği için ayrı Kotlin yardımcı sınıfı
- Android Studio / Gradle proje yapısı

## Henüz bulunmayanlar
- ArUco/AprilTag veya özel marker otomatik algılama
- Lens/çerçeve düzlemi perspektif düzeltmesi
- Göz bebeği merkezlerinin otomatik tespiti
- Fotoğraf üzerinde manuel nokta işaretleme ekranı
- Kalıcı müşteri kayıtları ve PDF raporu

Bu nedenle 0.1.0 sürümü ölçüm yapan/tıbbi cihaz niteliğinde bir uygulama değildir; kamera ve uygulama iskeletidir. Gerçek montaj ölçüsü üretmeden önce bilinen ölçülü kalibrasyon aparatıyla laboratuvar/tezgâh testleri, farklı çerçeveler ve telefonlarda doğrulama gerekir. Sonuçlar optisyen tarafından bağımsız ölçümle karşılaştırılmalıdır.

## Açma
1. ZIP'i bilgisayara çıkarın.
2. Android Studio'da `ProgresifOlcumPro` klasörünü açın.
3. Gradle senkronizasyonunu tamamlayın.
4. Android 8.0 (API 26) veya üzeri bir cihazda çalıştırın.

Not: Bu ortamda Android SDK/Gradle kurulu olmadığı için APK derlemesi yapılmadı. Android Studio ilk açılışta gerekli Gradle ve Android SDK bileşenlerini indirecektir.

## Kullanıcının mevcut kalibrasyon aparatı — doğrulanmış nominal geometri
- Üst sol–üst sağ referans merkezleri: 170 mm.
- Alt sol–alt sağ referans merkezleri: 170 mm.
- Sol üst–sol alt referans merkezleri: 60 mm.
- Sağ üst–sağ alt referans merkezleri: 60 mm.
- `CalibrationProfile.kt` içinde 170 × 60 mm nominal dikdörtgen profili tanımlıdır.
- Bu değerler kullanıcı tarafından bildirilmiştir; referans noktalarının fotoğrafta otomatik bulunması ve düzlem/perspektif doğrulaması henüz uygulanmamıştır.

## Kalibrasyon aparatı için ilk tasarım şartları
- Çerçeve ön yüzüne tekrarlanabilir şekilde oturmalı ve kaymamalı.
- Marker'ın bilinen fiziksel ölçüsü (öneri: 20–30 mm kare kod) üretim toleransıyla ölçülmeli.
- Marker, çerçeve ön düzlemiyle aynı düzlemde veya geometrik ofseti kesin tanımlı olmalı.
- Fotoğraf çekiminde kamera optik ekseni çerçeveye olabildiğince dik olmalı.
- Marker ve çerçevenin tamamı keskin ve görünür olmalı.

## GitHub üzerinden APK oluşturma (Android telefondan da yapılabilir)
Projeyi bir GitHub deposuna yükleyip `Actions` sekmesinden `Build Android APK` iş akışını çalıştırın. İşlem başarılı olursa `ProgresifOlcumPro-debug-apk` adlı artifact içinden `app-debug.apk` dosyasını indirebilirsiniz. Bu ilk APK yalnızca kamera/arayüz iskeletidir; otomatik ölçüm özelliği henüz yoktur.
