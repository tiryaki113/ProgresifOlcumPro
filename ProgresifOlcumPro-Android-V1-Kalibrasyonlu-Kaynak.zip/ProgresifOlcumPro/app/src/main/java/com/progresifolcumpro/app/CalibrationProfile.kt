package com.progresifolcumpro.app

/** User-confirmed geometry of the existing clip-on calibration frame. */
object CalibrationProfile {
    const val WIDTH_MM = 170.0
    const val HEIGHT_MM = 60.0

    /** Corner coordinates in millimetres after rectification: TL, TR, BR, BL. */
    val cornersMm = listOf(
        Point2D(0.0, 0.0),
        Point2D(WIDTH_MM, 0.0),
        Point2D(WIDTH_MM, HEIGHT_MM),
        Point2D(0.0, HEIGHT_MM)
    )
}
