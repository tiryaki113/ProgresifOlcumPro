package com.progresifolcumpro.app

/**
 * Geometry helpers for the assisted-measurement workflow.
 * Coordinates must be measured on the rectified frame plane after calibration.
 * This module intentionally does not claim automatic clinical-grade measurement.
 */
data class Point2D(val x: Double, val y: Double)

data class FrameMeasurements(
    val rightMonocularPdMm: Double,
    val leftMonocularPdMm: Double,
    val rightFittingHeightMm: Double,
    val leftFittingHeightMm: Double
)

object MeasurementMath {
    fun pixelsPerMm(markerLengthPixels: Double, markerLengthMm: Double): Double {
        require(markerLengthPixels > 0.0 && markerLengthMm > 0.0)
        return markerLengthPixels / markerLengthMm
    }

    /** Bridge center is the horizontal datum. Distances are returned as positive magnitudes. */
    fun calculate(
        bridgeCenter: Point2D,
        rightPupil: Point2D,
        leftPupil: Point2D,
        rightLensBottomAtPupil: Point2D,
        leftLensBottomAtPupil: Point2D,
        pixelsPerMm: Double
    ): FrameMeasurements {
        require(pixelsPerMm > 0.0)
        return FrameMeasurements(
            rightMonocularPdMm = kotlin.math.abs(bridgeCenter.x - rightPupil.x) / pixelsPerMm,
            leftMonocularPdMm = kotlin.math.abs(leftPupil.x - bridgeCenter.x) / pixelsPerMm,
            rightFittingHeightMm = kotlin.math.abs(rightLensBottomAtPupil.y - rightPupil.y) / pixelsPerMm,
            leftFittingHeightMm = kotlin.math.abs(leftLensBottomAtPupil.y - leftPupil.y) / pixelsPerMm
        )
    }
}
