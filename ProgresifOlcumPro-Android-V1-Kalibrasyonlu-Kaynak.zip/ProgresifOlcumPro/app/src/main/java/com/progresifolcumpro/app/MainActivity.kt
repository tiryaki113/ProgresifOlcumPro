package com.progresifolcumpro.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.File

private val Navy = Color(0xFF102A43)
private val Teal = Color(0xFF12A594)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Teal, background = Navy, surface = Color(0xFF183B56))) { AppRoot() } }
    }
}

@Composable
private fun AppRoot() {
    var showCamera by remember { mutableStateOf(false) }
    var selectedPhoto by remember { mutableStateOf<String?>(null) }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedPhoto = uri?.toString()
    }
    if (showCamera) {
        CameraCaptureScreen(
            onCaptured = { path -> selectedPhoto = path; showCamera = false },
            onClose = { showCamera = false }
        )
    } else if (selectedPhoto != null) {
        CapturedScreen(path = selectedPhoto!!, onBack = { selectedPhoto = null })
    } else {
        HomeScreen(
            onNewMeasurement = { showCamera = true },
            onChooseGallery = { galleryPicker.launch("image/*") }
        )
    }
}

@Composable
private fun HomeScreen(onNewMeasurement: () -> Unit, onChooseGallery: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Navy).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("PROGRESİF ÖLÇÜM PRO", style = MaterialTheme.typography.labelLarge, color = Teal)
        Text("Ölçüm merkezi", style = MaterialTheme.typography.headlineLarge, color = Color.White)
        Text("Fotoğrafla desteklenen progresif montaj ölçüm asistanı", color = Color(0xFFB8C7D1))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF183B56)), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Teal, modifier = Modifier.size(34.dp))
                Text("Yeni progresif ölçümü", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text("Arka kamerayla çekim yap. Klipsli kalibrasyon aparatını kadraja dahil et.", color = Color(0xFFB8C7D1))
                Button(onClick = onNewMeasurement, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                    Text("Fotoğraf çekimine başla", color = Navy)
                }
                OutlinedButton(onClick = onChooseGallery, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Image, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Galeriden fotoğraf seç", color = Color.White)
                }
                Text("Önceden çekilmiş fotoğraflarda da 170 × 60 mm kalibrasyon aparatının dört referans noktası görünür olmalıdır.", color = Color(0xFFB8C7D1), style = MaterialTheme.typography.bodySmall)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard("Müşteriler", "Kayıt modülü sıradaki aşamada", Icons.Default.PersonAdd, Modifier.weight(1f))
            FeatureCard("Geçmiş", "Ölçüm arşivi sıradaki aşamada", Icons.Default.History, Modifier.weight(1f))
        }
        Spacer(Modifier.weight(1f))
        Text("V1.0 • Ölçümler optisyen onayı gerektirir", color = Color(0xFF8FA8B7), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF183B56))) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = Teal)
            Text(title, color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = Color(0xFFB8C7D1), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CameraCaptureScreen(onCaptured: (String) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var hasPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var message by remember { mutableStateOf("Klipsli kalibrasyon aparatını gözlük çerçevesine sabitleyin.") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }

    LaunchedEffect(Unit) { if (!hasPermission) permissionLauncher.launch(Manifest.permission.CAMERA) }

    Column(Modifier.fillMaxSize().background(Navy)) {
        TextButton(onClick = onClose) { Text("‹ Geri", color = Color.White) }
        Text("Standart çekim", color = Color.White, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(horizontal = 18.dp))
        Text(message, color = Color(0xFFB8C7D1), modifier = Modifier.padding(18.dp))
        if (hasPermission) {
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val providerFuture = ProcessCameraProvider.getInstance(ctx)
                    providerFuture.addListener({
                        val provider = providerFuture.get()
                        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                        val imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
                        capture = imageCapture
                        try {
                            provider.unbindAll()
                            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                        } catch (e: Exception) { message = "Kamera başlatılamadı: ${e.localizedMessage}" }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }
            )
            Button(
                onClick = {
                    val imageCapture = capture ?: return@Button
                    val photo = File(context.cacheDir, "progresif_${System.currentTimeMillis()}.jpg")
                    val options = ImageCapture.OutputFileOptions.Builder(photo).build()
                    imageCapture.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(output: ImageCapture.OutputFileResults) { onCaptured(photo.absolutePath) }
                        override fun onError(exception: ImageCaptureException) { message = "Fotoğraf kaydedilemedi: ${exception.localizedMessage}" }
                    })
                },
                modifier = Modifier.fillMaxWidth().padding(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Teal)
            ) { Text("FOTOĞRAFI ÇEK", color = Navy) }
        } else {
            Text("Kamera izni gerekli. İzin verdikten sonra çekim ekranı açılacaktır.", color = Color.White, modifier = Modifier.padding(20.dp))
        }
    }
}

@Composable
private fun CapturedScreen(path: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Navy).padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Fotoğraf seçildi", color = Teal, style = MaterialTheme.typography.headlineSmall)
        Text(if (path.startsWith("content://")) "Galeriden seçilen fotoğraf hazır." else "Kamera fotoğrafı uygulamanın geçici alanına kaydedildi.", color = Color.White)
        Text("Sonraki geliştirme aşamasında bu ekrana kalibrasyon işareti algılama, göz bebeği işaretleme ve ölçüm düzeltme araçları eklenecek.", color = Color(0xFFB8C7D1))
        Text(if (path.startsWith("content://")) "Kaynak: Galeri" else "Dosya: ${File(path).name}", color = Color(0xFF8FA8B7), style = MaterialTheme.typography.bodySmall)
        Button(onClick = onBack, colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text("Ana ekrana dön", color = Navy) }
        Text("Bu sürüm henüz PD veya montaj yüksekliği üretmez. Ölçüm algoritması ve kalibrasyon doğrulaması tamamlanmadan sipariş ölçüsü olarak kullanılmamalıdır.", color = Color(0xFFFFD166), style = MaterialTheme.typography.bodySmall)
    }
}
