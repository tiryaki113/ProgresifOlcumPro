package com.progresifolcumpro.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.math.hypot

private val Navy = Color(0xFF102A43)
private val Teal = Color(0xFF12A594)
private val Marker = Color(0xFFFFC857)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Teal, background = Navy, surface = Color(0xFF183B56))) { AppRoot() } }
    }
}

@Composable
private fun AppRoot() {
    var showCamera by remember { mutableStateOf(false) }
    var selectedPhoto by remember { mutableStateOf<String?>(null) }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> selectedPhoto = uri?.toString() }
    if (showCamera) CameraCaptureScreen(onCaptured = { selectedPhoto = it; showCamera = false }, onClose = { showCamera = false })
    else if (selectedPhoto != null) MeasurementScreen(path = selectedPhoto!!, onBack = { selectedPhoto = null })
    else HomeScreen(onNewMeasurement = { showCamera = true }, onChooseGallery = { galleryPicker.launch("image/*") })
}

@Composable
private fun HomeScreen(onNewMeasurement: () -> Unit, onChooseGallery: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("PROGRESİF ÖLÇÜM PRO", style = MaterialTheme.typography.labelLarge, color = Teal)
        Text("Ölçüm merkezi", style = MaterialTheme.typography.headlineLarge, color = Color.White)
        Text("Klipsli referans aparat ile fotoğraf üzerinden yardımcı montaj ölçümü", color = Color(0xFFB8C7D1))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF183B56)), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Teal, modifier = Modifier.size(34.dp))
                Text("Yeni progresif ölçümü", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text("Aparatı gözlüğe sabitleyin. Fotoğrafta dört dış referans noktası, ortadaki üst işaret, iki göz bebeği ve cam alt kenarları görünür olmalı.", color = Color(0xFFB8C7D1))
                Button(onClick = onNewMeasurement, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text("Fotoğraf çekimine başla", color = Navy) }
                OutlinedButton(onClick = onChooseGallery, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Image, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Galeriden fotoğraf seç", color = Color.White) }
                Text("Bu sürümde noktalar kullanıcı tarafından işaretlenir; otomatik göz tanıma ve perspektif düzeltme henüz yoktur.", color = Marker, style = MaterialTheme.typography.bodySmall)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard("Müşteriler", "Kayıt modülü sonraki aşamada", Icons.Default.PersonAdd, Modifier.weight(1f))
            FeatureCard("Geçmiş", "Ölçüm arşivi sonraki aşamada", Icons.Default.History, Modifier.weight(1f))
        }
        Text("V1.1 • Sipariş öncesi optisyen doğrulaması zorunludur", color = Color(0xFF8FA8B7), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF183B56))) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, contentDescription = null, tint = Teal); Text(title, color = Color.White, style = MaterialTheme.typography.titleMedium); Text(subtitle, color = Color(0xFFB8C7D1), style = MaterialTheme.typography.bodySmall) } }
}

@Composable
private fun CameraCaptureScreen(onCaptured: (String) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var hasPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var message by remember { mutableStateOf("Klipsli kalibrasyon aparatını gözlük çerçevesine sabitleyin.") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    LaunchedEffect(Unit) { if (!hasPermission) permissionLauncher.launch(Manifest.permission.CAMERA) }
    Column(Modifier.fillMaxSize().background(Navy)) {
        TextButton(onClick = onClose) { Text("‹ Geri", color = Color.White) }
        Text("Arka kamera", color = Color.White, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(horizontal = 18.dp))
        Text(message, color = Color(0xFFB8C7D1), modifier = Modifier.padding(18.dp))
        if (hasPermission) {
            AndroidView(modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), factory = { ctx ->
                val previewView = PreviewView(ctx)
                val providerFuture = ProcessCameraProvider.getInstance(ctx)
                providerFuture.addListener({
                    val provider = providerFuture.get()
                    val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                    val imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build(); capture = imageCapture
                    try { provider.unbindAll(); provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture) }
                    catch (e: Exception) { message = "Kamera başlatılamadı: ${e.localizedMessage}" }
                }, ContextCompat.getMainExecutor(ctx)); previewView
            })
            Button(onClick = {
                val imageCapture = capture ?: return@Button
                val photo = File(context.cacheDir, "progresif_${System.currentTimeMillis()}.jpg")
                imageCapture.takePicture(ImageCapture.OutputFileOptions.Builder(photo).build(), ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(output: ImageCapture.OutputFileResults) { onCaptured(photo.absolutePath) }
                    override fun onError(exception: ImageCaptureException) { message = "Fotoğraf kaydedilemedi: ${exception.localizedMessage}" }
                })
            }, modifier = Modifier.fillMaxWidth().padding(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text("FOTOĞRAFI ÇEK", color = Navy) }
        } else Text("Kamera izni gerekli.", color = Color.White, modifier = Modifier.padding(20.dp))
    }
}

private val stepNames = listOf(
    "Üst sol dış referans noktasına dokunun",
    "Üst sağ dış referans noktasına dokunun",
    "Alt sol dış referans noktasına dokunun",
    "Alt sağ dış referans noktasına dokunun",
    "Aparatın üst orta yuvarlak merkez işaretine dokunun",
    "Fotoğrafta kişinin SAĞ göz bebeğinin merkezine dokunun (görüntünün solu)",
    "Fotoğrafta kişinin SOL göz bebeğinin merkezine dokunun (görüntünün sağı)",
    "Kişinin SAĞ camının alt kenarına, göz bebeğinin tam altına dokunun",
    "Kişinin SOL camının alt kenarına, göz bebeğinin tam altına dokunun"
)

@Composable
private fun MeasurementScreen(path: String, onBack: () -> Unit) {
    val context = LocalContext.current
    var bitmap by remember(path) { mutableStateOf<Bitmap?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(path) {
        try {
            bitmap = if (path.startsWith("content://")) context.contentResolver.openInputStream(Uri.parse(path))?.use { BitmapFactory.decodeStream(it) }
            else BitmapFactory.decodeFile(path)
            if (bitmap == null) loadError = "Fotoğraf açılamadı. Başka bir fotoğraf deneyin."
        } catch (e: Exception) { loadError = "Fotoğraf okunamadı: ${e.localizedMessage}" }
    }
    val points = remember(path) { mutableStateListOf<Point2D>() }
    var result by remember(path) { mutableStateOf<FrameMeasurements?>(null) }
    var validation by remember(path) { mutableStateOf<String?>(null) }
    var zoom by remember(path) { mutableFloatStateOf(1f) }
    var pan by remember(path) { mutableStateOf(Offset.Zero) }
    var draggingIndex by remember(path) { mutableIntStateOf(-1) }
    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        zoom = (zoom * zoomChange).coerceIn(1f, 8f)
        pan += panChange
    }

    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { TextButton(onClick = onBack) { Text("‹ Geri", color = Color.White) }; Spacer(Modifier.width(8.dp)); Text("Fotoğraf ölçüm işaretleme", color = Color.White, style = MaterialTheme.typography.titleLarge) }
        if (bitmap == null) { Text(loadError ?: "Fotoğraf yükleniyor…", color = Color.White); return@Column }
        val image = bitmap!!
        if (result == null) {
            Text("Adım ${points.size + 1} / ${stepNames.size}", color = Teal, style = MaterialTheme.typography.titleMedium)
            Text(stepNames.getOrNull(points.size) ?: "Tüm noktalar işaretlendi", color = Color.White)
            Text("İki parmakla yakınlaştır/uzaklaştır. Noktayı taşımak için üzerine basılı tutup sürükle. Şeffaf + işareti tam merkezi gösterir.", color = Color(0xFFB8C7D1), style = MaterialTheme.typography.bodySmall)
            BoxWithConstraints(Modifier.fillMaxWidth().background(Color.Black, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp))) {
                val boxWidth = constraints.maxWidth.toFloat()
                val boxHeight = boxWidth * image.height / image.width
                val baseScale = boxWidth / image.width
                val density = androidx.compose.ui.platform.LocalDensity.current
                val center = Offset(boxWidth / 2f, boxHeight / 2f)
                Box(Modifier.fillMaxWidth().height(with(density) { boxHeight.toDp() })
                    .transformable(state = transformState)
                    .pointerInput(points.size, image, zoom, pan) {
                        detectTapGestures { tap ->
                            val local = (tap - center - pan) / zoom + center
                            val ix = (local.x / baseScale).coerceIn(0f, image.width.toFloat())
                            val iy = (local.y / baseScale).coerceIn(0f, image.height.toFloat())
                            if (points.size < stepNames.size) points.add(Point2D(ix.toDouble(), iy.toDouble()))
                        }
                    }
                    .pointerInput(points.size, image, zoom, pan) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { pos ->
                                val local = (pos - center - pan) / zoom + center
                                val ix = local.x / baseScale; val iy = local.y / baseScale
                                val candidates = points.indices.map { i -> i to hypot(points[i].x - ix, points[i].y - iy) }
                                draggingIndex = candidates.minByOrNull { it.second }?.takeIf { it.second * baseScale * zoom < 55f }?.first ?: -1
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                if (draggingIndex in points.indices) {
                                    val local = (change.position - center - pan) / zoom + center
                                    points[draggingIndex] = Point2D(
                                        (local.x / baseScale).coerceIn(0f, image.width.toFloat()).toDouble(),
                                        (local.y / baseScale).coerceIn(0f, image.height.toFloat()).toDouble()
                                    )
                                }
                            },
                            onDragEnd = { draggingIndex = -1 },
                            onDragCancel = { draggingIndex = -1 }
                        )
                    }) {
                    Box(Modifier.fillMaxSize().graphicsLayer {
                        scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y
                    }) {
                        Image(bitmap = image.asImageBitmap(), contentDescription = "Ölçüm fotoğrafı", contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
                        Canvas(Modifier.fillMaxSize()) {
                            points.forEachIndexed { index, p ->
                                val x = (p.x * baseScale).toFloat(); val y = (p.y * baseScale).toFloat()
                                val tint = if (index == 4) Teal else Marker
                                val radius = 19.dp.toPx()
                                drawCircle(tint.copy(alpha = 0.18f), radius = radius, center = Offset(x, y))
                                drawCircle(tint.copy(alpha = 0.9f), radius = radius, center = Offset(x, y), style = Stroke(width = 1.5.dp.toPx()))
                                val arm = 12.dp.toPx()
                                drawLine(tint, Offset(x - arm, y), Offset(x + arm, y), strokeWidth = 1.8.dp.toPx())
                                drawLine(tint, Offset(x, y - arm), Offset(x, y + arm), strokeWidth = 1.8.dp.toPx())
                                drawCircle(Color.White.copy(alpha = 0.95f), radius = 2.dp.toPx(), center = Offset(x, y))
                            }
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { zoom = (zoom / 1.5f).coerceAtLeast(1f); if (zoom == 1f) pan = Offset.Zero }) { Text("−") }
                Text("Yakınlaştırma: ${((zoom - 1f) / 7f * 100).toInt() + 100}%", color = Color.White, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { zoom = (zoom * 1.5f).coerceAtMost(8f) }) { Text("+") }
                TextButton(onClick = { zoom = 1f; pan = Offset.Zero }) { Text("Sıfırla") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { if (points.isNotEmpty()) points.removeAt(points.lastIndex) }, enabled = points.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Son noktayı geri al") }
                Button(onClick = {
                    try {
                        val pxPerMmX = distance(points[0], points[1]) / CalibrationProfile.WIDTH_MM
                        val pxPerMmY = ((distance(points[0], points[2]) + distance(points[1], points[3])) / 2.0) / CalibrationProfile.HEIGHT_MM
                        require(pxPerMmX > 0 && pxPerMmY > 0) { "Kalibrasyon noktaları aynı yerde olamaz." }
                        result = FrameMeasurements(
                            rightMonocularPdMm = kotlin.math.abs(points[4].x - points[5].x) / pxPerMmX,
                            leftMonocularPdMm = kotlin.math.abs(points[6].x - points[4].x) / pxPerMmX,
                            rightFittingHeightMm = kotlin.math.abs(points[7].y - points[5].y) / pxPerMmY,
                            leftFittingHeightMm = kotlin.math.abs(points[8].y - points[6].y) / pxPerMmY
                        )
                        validation = "Yatay ölçek: %.3f px/mm • Dikey ölçek: %.3f px/mm".format(pxPerMmX, pxPerMmY)
                    } catch (e: Exception) { validation = e.message ?: "Ölçüm hesaplanamadı." }
                }, enabled = points.size == stepNames.size, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text("Ölçümleri hesapla", color = Navy) }
            }
            Text("Noktayı taşımak için uzun basıp sürükleyin. Şeffaf daire ve + işareti görüntüyü kapatmadan merkezlemeyi kolaylaştırır.", color = Color(0xFF8FA8B7), style = MaterialTheme.typography.labelSmall)
        } else {
            Text("Ölçüm sonuçları", color = Teal, style = MaterialTheme.typography.headlineSmall)
            val r = result!!
            ResultCard("Kişinin sağ monoküler PD", r.rightMonocularPdMm)
            ResultCard("Kişinin sol monoküler PD", r.leftMonocularPdMm)
            ResultCard("Kişinin sağ montaj yüksekliği", r.rightFittingHeightMm)
            ResultCard("Kişinin sol montaj yüksekliği", r.leftFittingHeightMm)
            Text(validation ?: "", color = Color(0xFFB8C7D1), style = MaterialTheme.typography.bodySmall)
            Text("ÖNEMLİ: Bu değerler elle işaretlenen noktalardan hesaplanan ön sonuçlardır. Perspektif düzeltmesi ve fiziksel ölçüm karşılaştırması yapılmamıştır. Cam siparişinde tek başına kullanmayın.", color = Marker, style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { points.clear(); result = null; validation = null; zoom = 1f; pan = Offset.Zero }, modifier = Modifier.fillMaxWidth()) { Text("Noktaları yeniden işaretle") }
        }
    }
}

private fun distance(a: Point2D, b: Point2D): Double = hypot(a.x - b.x, a.y - b.y)

@Composable
private fun ResultCard(label: String, value: Double) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF183B56)), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, modifier = Modifier.weight(1f))
            Text("%.1f mm".format(value), color = Teal, style = MaterialTheme.typography.titleLarge)
        }
    }
}
